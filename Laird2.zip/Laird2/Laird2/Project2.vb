﻿Public Class frmProject2
    Private Sub frmProject2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblLongDate.Text = Now.ToLongDateString
        lblShortDate.Text = Now.ToShortDateString
        lblLongTime.Text = Now.ToLongTimeString
        lblShortTime.Text = Now.ToShortTimeString
        lblDayOfWeek.Text = "Today is: " & Now.DayOfWeek
        lblDoWdddd.Text = "Today is: " & Now.ToString("dddd")


    End Sub

    Private Sub btnAboutProgram_Click(sender As Object, e As EventArgs) Handles btnAboutProgram.Click
        MessageBox.Show("This is a modified program of a course assignment. Purpose is to display current day, date, and time in various formats.", "About")
    End Sub

    ' Program originally modified by S.Daniel Laird via Mycanda. 
End Class
