﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmProject2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblLongDate = New System.Windows.Forms.Label()
        Me.lblShortDate = New System.Windows.Forms.Label()
        Me.lblLongTime = New System.Windows.Forms.Label()
        Me.lblShortTime = New System.Windows.Forms.Label()
        Me.lblDayOfWeek = New System.Windows.Forms.Label()
        Me.lblDoWdddd = New System.Windows.Forms.Label()
        Me.btnAboutProgram = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblLongDate
        '
        Me.lblLongDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblLongDate.Location = New System.Drawing.Point(23, 54)
        Me.lblLongDate.Name = "lblLongDate"
        Me.lblLongDate.Size = New System.Drawing.Size(151, 23)
        Me.lblLongDate.TabIndex = 0
        Me.lblLongDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblShortDate
        '
        Me.lblShortDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblShortDate.Location = New System.Drawing.Point(23, 100)
        Me.lblShortDate.Name = "lblShortDate"
        Me.lblShortDate.Size = New System.Drawing.Size(151, 23)
        Me.lblShortDate.TabIndex = 1
        Me.lblShortDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblLongTime
        '
        Me.lblLongTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblLongTime.Location = New System.Drawing.Point(23, 146)
        Me.lblLongTime.Name = "lblLongTime"
        Me.lblLongTime.Size = New System.Drawing.Size(151, 23)
        Me.lblLongTime.TabIndex = 2
        Me.lblLongTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblShortTime
        '
        Me.lblShortTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblShortTime.Location = New System.Drawing.Point(23, 192)
        Me.lblShortTime.Name = "lblShortTime"
        Me.lblShortTime.Size = New System.Drawing.Size(151, 23)
        Me.lblShortTime.TabIndex = 3
        Me.lblShortTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDayOfWeek
        '
        Me.lblDayOfWeek.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDayOfWeek.Location = New System.Drawing.Point(23, 238)
        Me.lblDayOfWeek.Name = "lblDayOfWeek"
        Me.lblDayOfWeek.Size = New System.Drawing.Size(151, 23)
        Me.lblDayOfWeek.TabIndex = 4
        Me.lblDayOfWeek.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDoWdddd
        '
        Me.lblDoWdddd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDoWdddd.Location = New System.Drawing.Point(23, 284)
        Me.lblDoWdddd.Name = "lblDoWdddd"
        Me.lblDoWdddd.Size = New System.Drawing.Size(151, 23)
        Me.lblDoWdddd.TabIndex = 5
        Me.lblDoWdddd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnAboutProgram
        '
        Me.btnAboutProgram.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnAboutProgram.Location = New System.Drawing.Point(12, 12)
        Me.btnAboutProgram.Name = "btnAboutProgram"
        Me.btnAboutProgram.Size = New System.Drawing.Size(175, 23)
        Me.btnAboutProgram.TabIndex = 8
        Me.btnAboutProgram.Text = "About"
        Me.btnAboutProgram.UseVisualStyleBackColor = False
        '
        'frmProject2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(202, 333)
        Me.Controls.Add(Me.btnAboutProgram)
        Me.Controls.Add(Me.lblDoWdddd)
        Me.Controls.Add(Me.lblDayOfWeek)
        Me.Controls.Add(Me.lblShortTime)
        Me.Controls.Add(Me.lblLongTime)
        Me.Controls.Add(Me.lblShortDate)
        Me.Controls.Add(Me.lblLongDate)
        Me.Name = "frmProject2"
        Me.Text = "Day - Date - Time ~ In VB"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblLongDate As Label
    Friend WithEvents lblShortDate As Label
    Friend WithEvents lblLongTime As Label
    Friend WithEvents lblShortTime As Label
    Friend WithEvents lblDayOfWeek As Label
    Friend WithEvents lblDoWdddd As Label
    Friend WithEvents btnAboutProgram As Button
End Class
